<?php
// conexion.php
$host = 'localhost';
$bd   = 'alondra';   // cambiá por el nombre real de tu BD
$user = 'root';            // usuario de MySQL
$pass = 'root';                // contraseña de MySQL

$dsn = "mysql:host=$host;dbname=$bd;charset=utf8mb4";

$opciones = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $opciones);
} catch (PDOException $e) {
    die('Error de conexión: ' . $e->getMessage());
}
