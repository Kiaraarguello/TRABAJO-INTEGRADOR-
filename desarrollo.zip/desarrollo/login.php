<?php
session_start();
require 'conexion.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT id, nombre, email, password_hash FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($password, $usuario['password_hash'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nombre'] = $usuario['nombre'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Correo o contraseña incorrectos';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Login - Alondra</title>
  <link rel="stylesheet" href="css/login.css">
</head>
<body>

  <section class="login">
    <form class="login__tarjeta" action="login.php" method="post">
      <h2 class="login__titulo">Iniciar sesión</h2>

      <?php if ($error): ?>
        <p style="color:red; margin-bottom:10px;"><?= htmlspecialchars($error) ?></p>
      <?php endif; ?>

      <input type="email" name="email" placeholder="Correo electrónico" required>
      <input type="password" name="password" placeholder="Contraseña" required>

      <button type="submit" class="login__boton">Entrar</button>

      <a href="#" class="login__enlace">¿Olvidaste tu contraseña?</a>
    </form>
  </section>

  <script src="js/login.js"></script>
</body>
</html>