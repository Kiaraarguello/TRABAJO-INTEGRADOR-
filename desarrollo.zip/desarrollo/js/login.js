document.addEventListener("DOMContentLoaded", () => { 
  const form = document.querySelector(".login__tarjeta");
  const emailInput = form.querySelector("input[name='email']");
  const passwordInput = form.querySelector("input[name='password']");

  const errorMsg = document.createElement("p");
  errorMsg.classList.add("login__error");
  errorMsg.style.color = "red";
  errorMsg.style.marginTop = "10px";
  form.appendChild(errorMsg);

  // si querés validar vacío en front:
  form.addEventListener("submit", (e) => {
    const user = emailInput.value.trim();
    const pass = passwordInput.value.trim();

    if (!user || !pass) {
      e.preventDefault();
      errorMsg.textContent = "Completa usuario y contraseña.";
    }
  });
});
