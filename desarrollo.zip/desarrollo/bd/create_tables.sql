CREATE DATABASE alondra;
USE alondra;

-- hotel
CREATE TABLE hotel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Usuarios (dueño, staff, huésped) para login
CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Habitaciones
CREATE TABLE habitacion (
    id INT PRIMARY KEY,
    hotel_id INT NOT NULL,
    numero_habitacion VARCHAR(20) NOT NULL,
    estado ENUM('disponible','ocupada','mantenimiento','bloqueada') NOT NULL DEFAULT 'disponible',
    bloqueada_mantenimiento TINYINT(1) NOT NULL DEFAULT 0,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_habitacion_hotel_numero (hotel_id, numero_habitacion),
    KEY idx_habitaciones_hotel (hotel_id),
    CONSTRAINT fk_habitaciones_hotel
        FOREIGN KEY (hotel_id) REFERENCES hotel(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);
drop table reserva;
drop table habitacion;
-- Reservas
CREATE TABLE reserva (
    id INT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,   -- ej: D-0004
    hotel_id INT NOT NULL,
    habitacion_id INT NOT NULL,
    nombre_huesped VARCHAR(100) NOT NULL, 
    regimen ENUM('BB','HB','AI') NOT NULL DEFAULT 'BB',
    fecha_check_in DATE NOT NULL,
    fecha_check_out DATE NOT NULL,
    estado ENUM('reservada','check_in','check_out','cancelada','no_show','late_checkout')
        NOT NULL DEFAULT 'reservada',
    monto_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_reservas_hotel_fechas (hotel_id, fecha_check_in, fecha_check_out),
    KEY idx_reservas_habitacion_fechas (habitacion_id, fecha_check_in, fecha_check_out),
    CONSTRAINT fk_reservas_hotel
        FOREIGN KEY (hotel_id) REFERENCES hotel(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_reservas_habitacion
        FOREIGN KEY (habitacion_id) REFERENCES habitacion(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);