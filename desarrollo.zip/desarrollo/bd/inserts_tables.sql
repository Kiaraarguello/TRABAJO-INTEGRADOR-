
-- HOTELES
INSERT INTO hotel (id, nombre, creado_en) VALUES
(1, 'Hilton Hotel Miami',   NOW()),
(2, 'Hilton Hotel Londres', NOW()),
(3, 'Hilton Hotel Posadas', NOW());


-- USUARIOS (login + huéspedes)
INSERT INTO usuario (id, nombre, password_hash, creado_en) VALUES

(1, 'ucp123', '123', NOW());


-- HABITACIONES
INSERT INTO habitacion (id, hotel_id, numero_habitacion, estado, bloqueada_mantenimiento, creado_en)
VALUES
(1, 1, '305', 'disponible', 0, NOW()),  
(2, 2, '412', 'disponible', 0, NOW()),  
(3, 1, '110', 'disponible', 0, NOW()),  
(4, 3, '317', 'disponible', 0, NOW()),  
(5, 3, '221', 'disponible', 0, NOW()),  
(6, 3, '220', 'disponible', 0, NOW()),  
(7, 2, '510', 'disponible', 0, NOW()),  
(8, 3, '118', 'disponible', 0, NOW()),  
(9, 1, '207', 'disponible', 0, NOW());  


-- RESERVAS 
INSERT INTO reserva (id, codigo, hotel_id, habitacion_id, nombre_huesped, regimen, fecha_check_in, fecha_check_out, estado, monto_total, creado_en) VALUES
(1, 'D-0004', 1, 1, 'Juan Pérez', 
 'BB', '2024-11-17', '2024-11-17',
 'check_out', 90000.00, NOW()),
(2, 'D-0003', 2, 2, 'María González', 
 'BB', '2024-11-17', '2024-10-09',
 'check_in', 350000.00, NOW()),
(3, 'D-0008', 1, 3, 'Carlos López', 
 'BB', '2024-10-07', '2024-10-11',
 'reservada', 260000.00, NOW()),
(4, 'D-0009', 3, 4, 'Ana Martínez', 
 'HB', '2024-10-06', '2024-10-09',
 'check_in', 310000.00, NOW()),
(5, 'D-0006', 3, 5, 'Pedro Ramírez', 
 'BB', '2024-10-05', '2024-10-06',
 'late_checkout', 120000.00, NOW()),
(6, 'D-0005', 3, 6, 'Laura Sánchez', 
 'HB', '2024-10-04', '2024-10-07',
 'check_in', 210000.00, NOW()),
(7, 'D-0007', 2, 7, 'Andrés Torres', 
 'AI', '2024-10-03', '2024-10-08',
 'check_in', 480000.00, NOW()),
(8, 'D-0002', 3, 8, 'Sofía Rodríguez', 
 'HB', '2024-09-29', '2024-10-01',
 'check_in', 102500.00, NOW()),
(9, 'D-0001', 1, 9, 'Javier Díaz', 
 'BB', '2024-09-01', '2024-09-04',
 'reservada', 198300.00, NOW());