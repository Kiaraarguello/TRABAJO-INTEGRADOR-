<?php
session_start();
require 'conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
  header('Location: login.php');
  exit;
}

// ejemplo MUY simple de datos para la tabla
$sql = "
    SELECT r.codigo,
           u.nombre AS huesped,
           h.nombre AS hotel,
           hab.numero_habitacion,
           r.regimen,
           DATE_FORMAT(r.fecha_check_in, '%d/%m') AS check_in,
           DATE_FORMAT(r.fecha_check_out, '%d/%m') AS check_out,
           r.estado,
           r.monto_total
    FROM reservas r
    JOIN usuarios u      ON u.id = r.huesped_id
    JOIN hoteles h       ON h.id = r.hotel_id
    JOIN habitaciones hab ON hab.id = r.habitacion_id
    ORDER BY r.id DESC
    LIMIT 50
";
$reservas = $pdo->query($sql)->fetchAll();
$totalResultados = count($reservas);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard Hotel</title>
  <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
  <div class="contenedor-general">
    <!-- Encabezado -->
    <div class="barra-superior">
      <div class="marca"><span class="punto"></span>Panel de Gestión Hotelera</div>
      <div class="acciones">
        <div class="buscador">
          <input id="buscador" type="search" placeholder="Buscar huésped, reserva, habitación..." />
        </div>
        <button class="boton" id="nueva-reserva">+ Nueva reserva</button>
      </div>
    </div>

    <!-- Indicadores (después los calculamos bien) -->
    <section class="indicadores" aria-label="Indicadores" id="indicadores">
      <!-- podés rellenar luego con PHP o JS -->
    </section>

    <!-- Filtros (por ahora solo visual) -->
    <form class="filtros" aria-label="Filtros" id="filtros">
      <div class="campo">
        <label for="filtro-fecha">Fecha</label>
        <input type="date" id="filtro-fecha" />
      </div>
      <div class="campo">
        <label for="filtro-hotel">Hotel</label>
        <select id="filtro-hotel">
          <option value="">Todos</option>
        </select>
      </div>
      <div class="campo">
        <label for="filtro-estado">Estado</label>
        <select id="filtro-estado">
          <option value="">Todos</option>
        </select>
      </div>
      <div class="campo">
        <button class="boton alternativo" type="button" id="aplicar">Aplicar filtros</button>
      </div>
    </form>

    <!-- Tabla -->
    <section class="tabla-general" aria-label="Reservas">
      <div class="tabla-encabezado">
        <h3>Reservas & Huéspedes</h3>
        <div class="etiqueta-resultado" id="resultado-total">
          <?= $totalResultados ?> resultados
        </div>
      </div>
      <div class="tabla-responsiva">
        <table role="table" id="tabla">
          <thead>
            <tr>
              <th>Reserva</th>
              <th>Huésped</th>
              <th>Hotel</th>
              <th>Habitación</th>
              <th>Régimen</th>
              <th>Check-in</th>
              <th>Check-out</th>
              <th>Estado</th>
              <th class="alinear-derecha">Total</th>
            </tr>
          </thead>
          <tbody id="cuerpo-tabla">
            <?php foreach ($reservas as $r): ?>
              <tr>
                <td>#<?= htmlspecialchars($r['codigo']) ?></td>
                <td>
                  <span class="simbolo-huesped"></span>
                  <?= htmlspecialchars($r['huesped']) ?>
                </td>
                <td><?= htmlspecialchars($r['hotel']) ?></td>
                <td><?= htmlspecialchars($r['numero_habitacion']) ?></td>
                <td><?= htmlspecialchars($r['regimen']) ?></td>
                <td><?= htmlspecialchars($r['check_in']) ?></td>
                <td><?= htmlspecialchars($r['check_out']) ?></td>
                <td><span class="etiqueta-estado estado-info">
                    <?= htmlspecialchars($r['estado']) ?>
                </span></td>
                <td class="alinear-derecha">$ <?= number_format($r['monto_total'], 0, ',', '.') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <section class="resumen-hoteles" aria-label="Resumen por hotel" id="resumen-hoteles">
      <!-- después lo llenamos con datos reales -->
    </section>
  </div>

  <script src="js/dashboard.js" defer></script>
</body>
</html>
